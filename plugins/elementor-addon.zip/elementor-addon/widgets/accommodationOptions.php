<?php


class Elementor_accommodationOptions extends \Elementor\Widget_Base
{

    public function get_name()
    {
        return 'accommodationOptions';
    }

    public function get_title()
    {
        return esc_html__('Accommodations Options', 'elementor-addon');
    }

    public function get_icon()
    {
        return 'eicon-code';
    }

    public function get_categories()
    {
        return ['basic'];
    }

    public function get_keywords()
    {
        return ['hello', 'world'];
    }

    protected function register_controls()
    {

        // Content Tab Start

        $this->start_controls_section(
            'top_section',
            [
                'label' => esc_html__('Top title', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title1',
            [
                'label' => esc_html__('Title', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'subtitle1',
            [
                'label' => esc_html__('Subtitle', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'bottom_section_title',
            [
                'label' => esc_html__('Types', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'oneAccommodation',
            [
                'label' => esc_html__('Accommodation', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'title',
                        'label' => esc_html__('Title', 'textdomain'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                    ],
                    [
                        'name' => 'image',
                        'label' => esc_html__('Choose Image', 'textdomain'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'label_block' => true,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
            ]
        );


        $this->end_controls_section();

        // Content Tab End


        // Style Tab Start

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => esc_html__('Title', 'elementor-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Text Color', 'elementor-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        // Style Tab End

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $accommodations = $settings['oneAccommodation'];

?>

        <style>
            .condosOptionsContainer {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
                gap: 25px;
            }

            .condosOptionsContainer h3 {
                color: #2c2d2c;
                font-size: 1.25rem;
                font-weight: 400;
                font-family: 'Open Sans', sans-serif;
            }

            .condosOptionsContainer p {
                text-align: center;
                color: #2c2d2c;
                font-size: 1.25rem;
                font-weight: 300;
            }

            .condosOPtionsContainerInner {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 25px;
            }

            .condosOPtionsContainerInner img {
                width: 100%;
                object-fit: contain;
            }

            .splide__slide {
                width: 100%;
                height: 50vh;
                padding: 15px;
            }

            .Title {
                padding: 15px;
                gap: 10px;
            }

            @media screen and (max-width: 600px) {
                .condosOPtionsContainerInner {
                    flex-direction: column;
                }

                .condosOPtionsContainerInner img {
                    width: 100%;
                    height: auto;
                }

                .option {
                    width: 100%;
                    margin-bottom: 15px;
                }
            }

            @media screen and (min-width: 1600px) {
                .condosOptionsContainer {
                    padding: 25px 10%;
                }
            }
        </style>

        <div class="condosOptionsContainer ">
            <h3>
                <?php echo $settings['title1'] ?>
            </h3>
            <p><?php echo $settings['subtitle1'] ?></p>
            <div class="condosOPtionsContainerInner">
                <?php foreach ($accommodations as $accommodation) { ?>
                    <div class="option">
                        <img src="<?php echo $accommodation['image']['url']; ?>" alt="">
                        <h3><?php echo $accommodation['title']; ?></h3>
                    </div>
                <?php } ?>
            </div>
        </div>

<?php
    }
}
