selectnav('main-top-menu', {
    activeclass: 'current-menu-item',
    label: '--- ' + udesign_selectnav_vars.selectnav_menu_label + ' --- ',
    indent: '--'
});