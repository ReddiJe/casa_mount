<?php
/*
Template Name: Aqur Privacy Policy
*/
?>
<?php
	get_header();
?>
    <div class="contactsBlock">
        <h1><?php the_title(); ?></h1>
    </div>
    <div class="textAllPrivacy">
        <?php the_content(); ?>
    </div>
<?php
    get_footer();
?>