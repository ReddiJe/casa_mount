<?php 
/*
Template Name: Patners
*/

get_header();
?>

<div class="partners">
			<div class="parnersContainer">
				<h1 class="partnersTitle bigTitle">Наша команда була або зараз пов'язана з наступними Компаніями :</h1>
				<div class="partnersInfoBlock">
					<div class="partner1">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="icon-logo">
						</a>
					</div>
					<div class="partner2">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="icon-logo">
						</a>
					</div>
					<div class="partner3">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="icon-logo">
						</a>
					</div>
					<div class="partner4">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="icon-logo">
						</a>
					</div>
					<div class="partner5">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="icon-logo">
						</a>
					</div>
					<div class="partner6">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner7">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner8">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="artner9">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner10">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner11">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner12">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner13">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner14">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner15">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner16">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
					<div class="partner17">
						<a class="partnerLink" href="#">
							<img class="partnerLinkImg" src="./img/partners/psyDuck.png" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php get_footer(); ?>