<?php /* Template Name: News Page */ 
get_header();
?>

<div class="regularTitleContainer">
        <h1 class="regularTitleBig">
            Reviews
        </h1>
        <h1 class="regularTitleNormal">
            Company Reviews
        </h1>
    </div>
    <div class="linkToOtherReviews">
        Go to Companies Reviews
    </div>
</div>


<?php get_footer();?>