<?php /* Template Name: Services Page */ 
get_header();
?>


    <div class="regularTitleContainer">
        <h1 class="regularTitleBig">
            Services
        </h1>
        <h1 class="regularTitleNormal">
            Services
        </h1>
    </div>


<?php get_footer();?>